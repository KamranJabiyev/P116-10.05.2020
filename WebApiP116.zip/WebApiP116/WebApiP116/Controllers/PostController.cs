﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApiP116.DAL;
using WebApiP116.Filters;
using WebApiP116.Models;

namespace WebApiP116.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly ILogger _logger;
        public PostController(AppDbContext db,ILogger<PostController> logger)
        {
            _db = db;
            _logger = logger;
        }
        /// <summary>
        /// Get All Post
        /// </summary>
        /// <returns></returns>
        // GET: api/Post
        [HttpGet]
        [TypeFilter(typeof(CustomFilter))]
        public IEnumerable<Post> Get()
        {
            _logger.LogInformation("Log message from Get all method");
            return _db.Posts;
        }

        /// <summary>
        /// Get post from Id
        /// </summary>
        /// <param name="id">For post</param>
        /// <returns></returns>
        // GET: api/Post/5
        [HttpGet("{id}", Name = "Get")]
        public async Task<ActionResult<Post>> Get(int id)
        {
            _logger.LogInformation("Log message from Get one data method");
            Post post =await _db.Posts.FindAsync(id);
            if (post == null) return NotFound();
            return post;
        }

        /// <summary>
        /// For creating new post
        /// </summary>
        /// <param name="post"></param>
        /// <returns></returns>
        // POST: api/Post
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] Post post)
        {
            if (!ModelState.IsValid) return BadRequest();
            await _db.Posts.AddAsync(post);
            await _db.SaveChangesAsync();
            return NoContent();
        }

        /// <summary>
        /// For updating exist post
        /// </summary>
        /// <param name="id"></param>
        /// <param name="post"></param>
        /// <returns></returns>
        // PUT: api/Post/5
        [HttpPut("{id}")]
        public async Task<ActionResult<Post>> Put(int id, [FromBody] Post post)
        {
            if (id != post.Id) return BadRequest();
            Post dbPost = await _db.Posts.FindAsync(id);
            if (dbPost==null) return NotFound();
            dbPost.Title = post.Title;
            dbPost.Content = post.Content;
            await _db.SaveChangesAsync();
            return dbPost;
        }

        /// <summary>
        /// For delete
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            Post post =await _db.Posts.FindAsync(id);
            if (post == null) return NotFound();
            _db.Posts.Remove(post);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
