﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiP116.Models;

namespace WebApiP116.DAL
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) :base(options)
        {
        }
        public DbSet<Post> Posts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Post>().HasData(
                new Post { Id=1,Title="Post1",Content="1 Post Content"}, 
                new Post { Id=2,Title="Post2",Content="2 Post Content"},
                new Post { Id = 3, Title = "Post3", Content = "3 Post Content" }
            );
        }
    }
}
